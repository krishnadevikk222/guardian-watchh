const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const twilio = require('twilio');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend/public')));

// ── Twilio client ──
const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);
const TWILIO_FROM = process.env.TWILIO_PHONE_NUMBER; // your Twilio number

// ── In-memory state ──
let sosActive = false;
let currentLocation = { lat: 11.0168, lng: 76.9558, address: 'Gandhipuram, Coimbatore, TN' };
let connectedSockets = new Set();

// ── Contacts (store in DB in production) ──
const CONTACTS = [
  { name: 'Amma',        relation: 'Mother',      phone: process.env.CONTACT_1 },
  { name: 'Appa',        relation: 'Father',       phone: process.env.CONTACT_2 },
  { name: 'Harini',      relation: 'Best friend',  phone: process.env.CONTACT_3 },
  { name: 'Rajan Uncle', relation: 'Neighbour',    phone: process.env.CONTACT_4 },
  { name: 'Meena Akka',  relation: 'Sister',       phone: process.env.CONTACT_5 },
];

// ── Safe spots (preloaded offline map data) ──
const SAFE_SPOTS = [
  { name: 'Murugan Provision Store', distance: 80,  direction: 'East',      type: 'shop',     lat: 11.0170, lng: 76.9565 },
  { name: 'Gandhipuram Police Booth',distance: 320, direction: 'Northeast', type: 'police',   lat: 11.0195, lng: 76.9580 },
  { name: 'GRH Hospital',            distance: 850, direction: 'North',     type: 'hospital', lat: 11.0240, lng: 76.9558 },
];

// ── ROUTES ──

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'Guardian Watch backend running', sosActive, contacts: CONTACTS.length });
});

// Get contacts
app.get('/api/contacts', (req, res) => {
  res.json(CONTACTS.map(c => ({ ...c, phone: c.phone ? '***' + c.phone.slice(-4) : 'Not set' })));
});

// Get safe spots
app.get('/api/safe-spots', (req, res) => {
  res.json(SAFE_SPOTS);
});

// Update location (called by watch every 30s)
app.post('/api/location', (req, res) => {
  const { lat, lng, address } = req.body;
  currentLocation = { lat, lng, address: address || currentLocation.address };
  // Broadcast to all connected family members
  io.emit('location-update', currentLocation);
  res.json({ success: true, location: currentLocation });
});

// ── SOS ACTIVATE ──
app.post('/api/sos/activate', async (req, res) => {
  if (sosActive) return res.json({ success: true, message: 'SOS already active' });
  sosActive = true;

  const mapsLink = `https://maps.google.com/?q=${currentLocation.lat},${currentLocation.lng}`;
  const smsBody = `🚨 GUARDIAN WATCH SOS ALERT!\n\nYour family member needs help NOW!\n\nLocation: ${currentLocation.address}\nMap: ${mapsLink}\n\nPlease respond immediately!`;

  const results = [];

  // Call and SMS all contacts simultaneously
  await Promise.allSettled(CONTACTS.map(async (contact) => {
    if (!contact.phone) return;
    try {
      // Make voice call
      const call = await twilioClient.calls.create({
        to: contact.phone,
        from: TWILIO_FROM,
        twiml: `<Response>
          <Say voice="woman" language="en-IN">
            Emergency Alert! Guardian Watch SOS activated. Your family member needs help immediately.
            Their location is ${currentLocation.address}.
            Please call them back or go to their location right now.
            This is an automated emergency alert from Guardian Watch.
          </Say>
          <Pause length="2"/>
          <Say voice="woman" language="ta-IN">
            அவசர எச்சரிக்கை! உங்கள் குடும்பத்தினர் இப்போது உதவி தேவை.
            இடம்: ${currentLocation.address}. உடனே அழையுங்கள்.
          </Say>
        </Response>`,
      });

      // Send SMS with location
      const sms = await twilioClient.messages.create({
        to: contact.phone,
        from: TWILIO_FROM,
        body: smsBody,
      });

      results.push({ name: contact.name, call: call.sid, sms: sms.sid, status: 'success' });
    } catch (err) {
      results.push({ name: contact.name, status: 'failed', error: err.message });
    }
  }));

  // Broadcast SOS to all connected browsers (family dashboard)
  io.emit('sos-activated', {
    location: currentLocation,
    mapsLink,
    timestamp: new Date().toISOString(),
    contacts: results,
  });

  res.json({ success: true, message: 'SOS activated', results });
});

// ── SOS CANCEL ──
app.post('/api/sos/cancel', (req, res) => {
  sosActive = false;
  io.emit('sos-cancelled', { timestamp: new Date().toISOString() });

  // Notify family SOS is cancelled
  CONTACTS.forEach(async (contact) => {
    if (!contact.phone) return;
    try {
      await twilioClient.messages.create({
        to: contact.phone,
        from: TWILIO_FROM,
        body: `✅ Guardian Watch: SOS cancelled. Your family member is now safe. No further action needed.`,
      });
    } catch (e) {}
  });

  res.json({ success: true, message: 'SOS cancelled' });
});

// ── CALL POLICE ──
app.post('/api/call/police', async (req, res) => {
  const POLICE_NUMBER = process.env.POLICE_NUMBER || '+91100'; // real: 100
  try {
    // In production this dials 100 directly
    // For demo/dev, it calls a test number
    const call = await twilioClient.calls.create({
      to: process.env.TEST_POLICE_NUMBER || CONTACTS[0]?.phone,
      from: TWILIO_FROM,
      twiml: `<Response>
        <Say voice="woman" language="en-IN">
          Emergency! Guardian Watch distress call.
          A person needs police assistance immediately.
          Location: ${currentLocation.address}.
          Coordinates: ${currentLocation.lat}, ${currentLocation.lng}.
          Please dispatch police immediately.
        </Say>
      </Response>`,
    });

    // Also send SMS to police (some Indian states support this)
    io.emit('police-called', {
      location: currentLocation,
      callSid: call.sid,
      timestamp: new Date().toISOString(),
    });

    res.json({ success: true, message: 'Police called', callSid: call.sid });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// ── CALL SPECIFIC CONTACT ──
app.post('/api/call/contact', async (req, res) => {
  const { name } = req.body;
  const contact = CONTACTS.find(c => c.name.toLowerCase().includes(name.toLowerCase()));
  if (!contact) return res.status(404).json({ success: false, message: 'Contact not found' });

  try {
    const call = await twilioClient.calls.create({
      to: contact.phone,
      from: TWILIO_FROM,
      twiml: `<Response>
        <Say voice="woman" language="en-IN">
          Guardian Watch emergency call. Your family member needs help at ${currentLocation.address}.
          Please respond immediately.
        </Say>
      </Response>`,
    });
    res.json({ success: true, name: contact.name, callSid: call.sid });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// ── SEND BLUETOOTH MESH ALERT (simulated via SMS to nearby numbers) ──
app.post('/api/alert/nearby', async (req, res) => {
  // In real hardware: BLE broadcast
  // In web demo: send alert to registered nearby helper numbers
  io.emit('nearby-alert', {
    location: currentLocation,
    message: 'Emergency nearby! Someone needs help!',
    timestamp: new Date().toISOString(),
  });
  res.json({ success: true, message: 'Nearby alert broadcast' });
});

// ── VOICE COMMAND PROCESSOR ──
app.post('/api/voice/command', async (req, res) => {
  const { transcript, lang } = req.body;
  const text = transcript.toLowerCase().trim();
  const isTamil = lang === 'ta-IN' || /[\u0B80-\u0BFF]/.test(text);

  let action = null;
  let response = '';
  let responseTa = '';

  // Police
  if (text.includes('100') || text.includes('police') || text.includes('போலீஸ்')) {
    action = 'call-police';
    response = 'Calling police now. Your location is being shared.';
    responseTa = 'போலீஸுக்கு இப்போதே அழைக்கிறோம். உங்கள் இடம் பகிரப்படுகிறது.';
    // Auto-trigger police call
    try {
      await twilioClient.calls.create({
        to: process.env.TEST_POLICE_NUMBER || CONTACTS[0]?.phone,
        from: TWILIO_FROM,
        twiml: `<Response><Say voice="woman" language="en-IN">Emergency! Guardian Watch. Location: ${currentLocation.address}. Please help immediately.</Say></Response>`,
      });
    } catch (e) {}
  }
  // SOS
  else if (text.includes('help') || text.includes('sos') || text.includes('உதவி') || text.includes('ஆபத்து')) {
    action = 'activate-sos';
    response = 'Activating SOS. Calling all family members now.';
    responseTa = 'SOS ஆரம்பிக்கிறது. குடும்பத்தினர் அனைவரையும் அழைக்கிறோம்.';
  }
  // Navigate
  else if (text.includes('police booth') || text.includes('போலீஸ் அரங்கு')) {
    action = 'navigate-police';
    response = 'Navigating to Gandhipuram Police Booth. Head northeast for 320 metres.';
    responseTa = 'காந்திபுரம் போலீஸ் அரங்கிற்கு வழிகாட்டுகிறோம். வடகிழக்கு திசையில் 320 மீட்டர் செல்லுங்கள்.';
  }
  else if (text.includes('hospital') || text.includes('மருத்துவமனை')) {
    action = 'navigate-hospital';
    response = 'Navigating to GRH Hospital. Head north for 850 metres.';
    responseTa = 'GRH மருத்துவமனைக்கு வழிகாட்டுகிறோம். வடக்கு திசையில் 850 மீட்டர் செல்லுங்கள்.';
  }
  else if (text.includes('shop') || text.includes('store') || text.includes('கடை')) {
    action = 'navigate-shop';
    response = 'Navigating to Murugan Store. Head east, just 80 metres away.';
    responseTa = 'முருகன் கடைக்கு வழிகாட்டுகிறோம். கிழக்கு திசையில் வெறும் 80 மீட்டர்.';
  }
  // Safe
  else if (text.includes('i am safe') || text.includes('பத்திரம்') || text.includes('safe')) {
    action = 'cancel-sos';
    response = 'Glad you are safe. SOS cancelled. Family notified.';
    responseTa = 'நீங்கள் பத்திரமாக இருக்கிறீர்கள். SOS நிறுத்தப்பட்டது. குடும்பத்தினர் தெரிவிக்கப்பட்டனர்.';
  }
  // Siren
  else if (text.includes('siren') || text.includes('சைரன்')) {
    action = 'start-siren';
    response = 'Siren activated! Stay where you are, help is coming.';
    responseTa = 'சைரன் ஆரம்பித்தது! நிற்கும் இடத்தில் இருங்கள், உதவி வருகிறது.';
  }
  // Call contact by name
  else {
    const contact = CONTACTS.find(c => text.includes(c.name.toLowerCase()));
    if (contact) {
      action = `call-${contact.name.toLowerCase().replace(' ', '-')}`;
      response = `Calling ${contact.name}. Sharing your live location.`;
      responseTa = `${contact.name} அழைக்கிறோம். உங்கள் இடம் பகிரப்படுகிறது.`;
      try {
        await twilioClient.calls.create({
          to: contact.phone,
          from: TWILIO_FROM,
          twiml: `<Response><Say voice="woman" language="en-IN">Guardian Watch emergency. Your family member needs help at ${currentLocation.address}.</Say></Response>`,
        });
      } catch (e) {}
    } else {
      response = 'I heard you. How can I help? Say help, call police, or navigate to safety.';
      responseTa = 'கேட்டேன். உதவி, போலீஸ் அழை, அல்லது வழிகாட்டு என்று சொல்லுங்கள்.';
    }
  }

  res.json({
    action,
    response: isTamil ? responseTa : response,
    responseTa,
    responseEn: response,
    lang: isTamil ? 'ta-IN' : 'en-IN',
  });
});

// ── SOCKET.IO — Real-time family dashboard ──
io.on('connection', (socket) => {
  connectedSockets.add(socket.id);
  console.log('Client connected:', socket.id, '| Total:', connectedSockets.size);

  // Send current state to new connection
  socket.emit('init-state', {
    sosActive,
    location: currentLocation,
    contacts: CONTACTS.map(c => ({ name: c.name, relation: c.relation })),
    safeSpots: SAFE_SPOTS,
  });

  socket.on('location-update', (data) => {
    currentLocation = { ...currentLocation, ...data };
    socket.broadcast.emit('location-update', currentLocation);
  });

  socket.on('sos-trigger', async () => {
    // Trigger full SOS from socket (watch button press)
    await fetch(`http://localhost:${PORT}/api/sos/activate`, { method: 'POST' });
  });

  socket.on('disconnect', () => {
    connectedSockets.delete(socket.id);
    console.log('Client disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🛡️  Guardian Watch Backend running on port ${PORT}`);
  console.log(`   Frontend: http://localhost:${PORT}`);
  console.log(`   API:      http://localhost:${PORT}/api/health\n`);
});
